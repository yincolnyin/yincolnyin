import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.table.api.EnvironmentSettings;
import org.apache.flink.table.api.TableSchema;
import org.apache.flink.table.api.bridge.java.StreamTableEnvironment;
import org.apache.flink.table.catalog.ObjectPath;
import org.apache.flink.table.catalog.exceptions.DatabaseNotExistException;
import org.apache.flink.table.catalog.exceptions.TableNotExistException;
import org.apache.flink.table.types.logical.LogicalType;
import org.apache.flink.table.types.logical.LogicalTypeFamily;
import org.junit.Test;

import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class JdbcCatalogTest1 {
    @Test
    public void testOracle() throws DatabaseNotExistException, TableNotExistException {

        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        EnvironmentSettings settings = EnvironmentSettings.newInstance().inStreamingMode().useBlinkPlanner().build();
        StreamTableEnvironment tableEnvironment = StreamTableEnvironment.create(env, settings);

        String catalogName = "oracle-catalog";
        String defaultDatabase = "orcl";
        String username = "yjk";
        String password = "123456";
        // String
        // jdbcUrl=String.format("jdbc:mysql://localhost:3306/%s?useUnicode=true&characterEncoding=utf8&serverTimezone=UTC",defaultDatabase);
        String jdbcUrl = "jdbc:oracle:thin:@192.168.1.135:1521";

        OracleCatalogTest oracleCatalog = new OracleCatalogTest(catalogName, defaultDatabase, username, password,
                jdbcUrl);
        tableEnvironment.registerCatalog(catalogName, oracleCatalog);
        tableEnvironment.useCatalog(catalogName);

        System.out.println(oracleCatalog.getTable(new ObjectPath("YJK", "CHARTEST")).getSchema().getFieldCount());
        // System.out.println(oracleCatalog.listTables(new
        // ObjectPath("YJK","STUDENT").getDatabaseName()));
        // System.out.println(oracleCatalog.getDatabase(new
        // ObjectPath("YJK","STUDENT").getDatabaseName()));
        // System.out.println(oracleCatalog.listDatabases());
        // oracleCatalog.tableExists(new ObjectPath("YJK",""));
    }

    @Test
    public void testMysql() throws TableNotExistException {
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        EnvironmentSettings settings = EnvironmentSettings.newInstance().inStreamingMode().useBlinkPlanner().build();
        StreamTableEnvironment tableEnvironment = StreamTableEnvironment.create(env, settings);

        String catalogName = "mysql-catalog";
        String defaultDatabase = "day01";
        String username = "root";
        String password = "123456";
        // String
        // jdbcUrl=String.format("jdbc:mysql://localhost:3306/%s?useUnicode=true&characterEncoding=utf8&serverTimezone=UTC",defaultDatabase);
        String jdbcUrl = "jdbc:mysql://localhost:3306/";

        MysqlCatalogTest mysqlCatalog = new MysqlCatalogTest(catalogName, defaultDatabase, username, password, jdbcUrl);
        tableEnvironment.registerCatalog(catalogName, mysqlCatalog);
        tableEnvironment.useCatalog(catalogName);

        // System.out.println(mysqlCatalog.getDatabase(new
        // ObjectPath("day01","tables").getDatabaseName()));
        // System.out.println(mysqlCatalog.listTables(new
        // ObjectPath("day01","tables").getDatabaseName()));
        // System.out.println(mysqlCatalog.listDatabases());
        //System.out.println(mysqlCatalog.getTable(new ObjectPath("day01", "t_product")).getSchema());
        TableSchema schema = mysqlCatalog.getTable(new ObjectPath("day01", "t_product")).getSchema();
        String fieldDef;
        //System.out.println(mysqlCatalog.getTable(new ObjectPath("information", "tables")).getSchema());
        boolean time2Iint = true;
        fieldDef = getHbaseFieldDef(schema,time2Iint);
        String flinkTableName="day01.t_product";


        String tableDef=String.format("Create table IF NOT EXISTS %s (\n%s)\n",flinkTableName,
                fieldDef);
        System.out.println(tableDef);

    }

    private static String getHbaseFieldDef(TableSchema schema, boolean time2Iint) {
        int fieldCount=schema.getFieldCount();
        String fieldDef ;
         fieldDef= IntStream.range(1,fieldCount).mapToObj(i->{
                    String fieldName=schema.getFieldName(i).get();
                    if("time".equalsIgnoreCase(fieldName)){
                        fieldName="`time`";
                    }

                    return String.format("%s %s",fieldName,"STRING");
                })
                .collect(Collectors.joining(",","rowkey STRING,\nINFO ROW<",">,\nPRIMARY KEY (rowkey) NOT ENFORCED\n"));
        return fieldDef ;
    }

    public static String getPkDef(TableSchema schema){
        String pkDef=schema.getPrimaryKey().get().toString();
        return pkDef;
    }

}
