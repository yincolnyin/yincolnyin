import org.junit.Test;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class OracleDBUtil {
    static
    {
        try
        {
            // 加载Oracle驱动程序
            Class.forName("oracle.jdbc.driver.OracleDriver").newInstance();
            System.out.println("oracle驱动程序加载中！");
        }
        catch(InstantiationException e1)
        {
            System.out.println("实例异常");
        }
        catch(IllegalAccessException e2)
        {
            System.out.println("访问异常");
        }
        catch(ClassNotFoundException e3)
        {
            System.out.println("MySQL驱动类找不到");
        }
    }



    /***
     * 返回一个数据库连接
     */
    @Test
    public  void getConnection()
    {
        Connection connection = null;// 创建一个数据库连接
        try
        {
            System.out.println("开始尝试连接数据库！");
            String url = "jdbc:oracle:thin:@192.168.1.135:1521:orcl";//Oracle的默认数据库名
            String user = "yjk";// 系统默认的用户名
            String password = "123456";// 安装时设置的密码
            connection = DriverManager.getConnection(url, user, password);// 获取连接
            System.out.println(url);
            System.out.println("用户名："+user+"\t"+"密码：******");
            System.out.println("数据库连接成功！");


            String sql = "select * from YJK.CHARTEST ";

            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            System.out.println(preparedStatement);
            List<Map<String,String>> rows = new ArrayList<>();
            ResultSet resultSet = preparedStatement.executeQuery();
            int count = preparedStatement.getMetaData().getColumnCount();
            while (resultSet.next()){
                Map<String,String> row=new HashMap<String,String>();
                for(int i=1;i<=count;i++){
                    String key=preparedStatement.getMetaData().getColumnName(i).toLowerCase();
                    String val=resultSet.getString(i);
                    row.put(key,val);
                }
                rows.add(row);
                System.out.println(row);
            }
            System.out.println(rows);
            connection.close();
        }
        catch (Exception e)
        {
            e.printStackTrace();

        }


    }

}
