import org.apache.flink.connector.jdbc.catalog.JdbcCatalog;
import org.apache.flink.connector.jdbc.catalog.PostgresCatalog;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.table.api.EnvironmentSettings;
import org.apache.flink.table.api.bridge.java.StreamTableEnvironment;
import org.apache.flink.table.catalog.ObjectPath;
import org.apache.flink.table.catalog.exceptions.DatabaseNotExistException;
import org.apache.flink.table.catalog.exceptions.TableNotExistException;
import org.junit.Test;

public class JdbcCatalogTestPg{

    @Test
    public  void test1() throws DatabaseNotExistException, TableNotExistException {
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        EnvironmentSettings settings = EnvironmentSettings.newInstance().inStreamingMode().useBlinkPlanner().build();
        StreamTableEnvironment tableEnvironment = StreamTableEnvironment.create(env, settings);

//        String catalogName = "mysql-catalog";
//        String defaultDatabase = "default_database";
//        String username = "root";
//        String password = "123456";
//        String jdbcUrl = "jdbc:mysql://localhost:3306/day01?useUnicode=true&characterEncoding=utf8&serverTimezone=UTC";
        String pgUrl = "jdbc:postgresql://localhost:5432/" ;//myDB为数据库名
        String catalogNamePg = "mypg";
        String defaultDatabasePg = "postgres";
        String usernamePg = "postgres";
        String passwordPg = "123456";
        //JdbcCatalog mysqlCatalog = new JdbcCatalog(catalogName, defaultDatabase, username, password, jdbcUrl);
//        MysqlCatalogTest mysqlCatalog = new MysqlCatalogTest(catalogName, defaultDatabase, username, password, jdbcUrl);
//        tableEnvironment.registerCatalog(catalogName,mysqlCatalog);
//        tableEnvironment.useCatalog(catalogName);



        //PostgresCatalog postgresCatalog =new JdbcCatalogTestPg(catalogNamePg,defaultDatabasePg,usernamePg,passwordPg,pgUrl);
        JdbcCatalog catalog = new JdbcCatalog(catalogNamePg, defaultDatabasePg, usernamePg, passwordPg, pgUrl);
        tableEnvironment.registerCatalog(catalogNamePg,catalog);
        tableEnvironment.useCatalog(catalogNamePg);
        //System.out.println(mysqlCatalog.getDatabase(new ObjectPath("information_schema","tables").getDatabaseName()));
        System.out.println(catalog.listTables(new ObjectPath("mydb","test").getDatabaseName()));
        //System.out.println(mysqlCatalog.listDatabases());
        //System.out.println(mysqlCatalog.getTable(new ObjectPath("information", "tables")));
        //System.out.println(catalog.getTable(new ObjectPath("mydb", "test")).getSchema());
        //System.out.println(catalog.listDatabases());
    }

}
