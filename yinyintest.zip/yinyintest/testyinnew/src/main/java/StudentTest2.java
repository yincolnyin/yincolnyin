import org.junit.Test;

public class StudentTest2 {
    @Test
    public void test() {
        //需求：我要使用Student类中的study()方法
        //但是，这一次我的要求是，不要直接创建Student的对象
        //让你使用StudentDemo帮你创建对象
        //引用studentdemo类去调用getstudent方法，返回一个student类
        //在studentdemo类中方法返回值类型是类，是告诉你这个方法返回一个返回值类的对象
        StudentDemo sd = new StudentDemo();

        Student s = sd.getStudent(); //new Student(); Student s = new Student();
        s.study();
    }
    @Test
    public void test1(){
        System.out.println("sssssss");
    }
}
