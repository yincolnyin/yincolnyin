import com.alibaba.fastjson.JSONObject;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class test2 {

    public test2(){

    }




    public static void main(String[] args) {
        JsonUtil jsonUtil = new JsonUtil();
        String jsonFile = jsonUtil.readJsonFile(new File("1.json"));
        JSONObject jsonObject = JSONObject.parseObject(jsonFile);
        Map<String, Object> stringObjectMap = jsonObject.getJSONObject("source").getInnerMap();
        //{key1=value1, key2=value2}
        ArrayList<Map.Entry<String, Object>> entries = new ArrayList<>(stringObjectMap.entrySet());

        String collect = stringObjectMap.entrySet().stream().map(e -> String.format("'%s'='%s'", e.getKey(), e.getValue())).collect(Collectors.joining(","));
        System.out.println(collect);

        //ArrayList<Object> stringsValue = new ArrayList<>(stringObjectMap.values());




    }

}
