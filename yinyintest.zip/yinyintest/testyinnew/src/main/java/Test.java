class Person {
    private String name;
    private int age;

    public Person() {
        System.out.println("******");
    }

    public Person(int num) {
        name = "15";
        setage(num);
    }

    public void setage(int num) {
        if (num > 0 && num < 150) {
            age = num;
        } else {
            age = 0;
        }
    }

    public int getAge() {
        
        return age;
    }

    public void getPersonInfo() {
        System.out.println("姓名:" + name + ", 年龄:" + age);
    }
}

public class Test {
    public static void main(String[] args) {
        Person per1 = new Person(20);
        per1.getPersonInfo();
    }
}
