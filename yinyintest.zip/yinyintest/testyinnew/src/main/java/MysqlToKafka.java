import org.apache.flink.api.common.RuntimeExecutionMode;
import org.apache.flink.streaming.api.CheckpointingMode;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.table.api.EnvironmentSettings;
import org.apache.flink.table.api.Table;
import org.apache.flink.table.api.TableResult;
import org.apache.flink.table.api.bridge.java.StreamTableEnvironment;

public class MysqlToKafka {

    public static void main(String[] args) throws Exception {
//        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
//        EnvironmentSettings envSettings = EnvironmentSettings.newInstance()
//                .useBlinkPlanner()
//                .inStreamingMode()
//                .build();
//        env.setParallelism(3);
//        // note: 增量同步需要开启CK
//        env.enableCheckpointing(10000);
//        StreamTableEnvironment tableEnvironment = StreamTableEnvironment.create(env, envSettings);
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        EnvironmentSettings envSettings = EnvironmentSettings.newInstance()
                .useBlinkPlanner()
                .inStreamingMode()
                .build();
        env.setParallelism(1);
        env.setRuntimeMode(RuntimeExecutionMode.STREAMING);
        //env.enableCheckpointing(60000);
        env.getCheckpointConfig().setCheckpointingMode(CheckpointingMode.EXACTLY_ONCE);
        env.getCheckpointConfig().setMaxConcurrentCheckpoints(1);
        // note: 增量同步需要开启CK
        env.enableCheckpointing(10000);
        StreamTableEnvironment tableEnvironment = StreamTableEnvironment.create(env, envSettings);

        tableEnvironment.executeSql(" CREATE TABLE demoOrders (\n" +
                "          `id` INT ,\n" +
                "          `sname` string ,\n" +
                "          `gender` int,\n" +
                "          `grade` string,\n" +
                "          `timestamp` timestamp,\n" +
                "          primary key (id)  NOT ENFORCED " +
                "         ) WITH (\n" +
                "          'connector' = 'mysql-cdc',\n" +
                "          'hostname' = 'localhost',\n" +
                "          'port' = '3306',\n" +
                "          'username' = 'root',\n" +
                "          'password' = '123456',\n" +
                "          'database-name' = 'day01',\n" +
                "          'table-name' = 't_student',\n" +
                "          'scan.startup.mode' = 'latest-offset'      " +
                " )");

        tableEnvironment.executeSql("CREATE TABLE sink (\n" +
                "          `id` INT ,\n" +
                "          `sname` string ,\n" +
                "          `gender` int,\n" +
                "          `grade` string,\n" +
                "          `timestamp` timestamp,\n" +
                "          primary key (id)  NOT ENFORCED " +
                ") WITH (\n" +
                "    'connector' = 'kafka',\n" +
                "    'properties.bootstrap.servers' = 'hadoop162:9092,hadoop163:9092,hadoop164:9692',\n" +
                "    'topic' = 'test1',\n" +
                //"    'sink.semantic' = 'exactly-once',\n"+
                //"    'transaction.timeout.ms' = '300000',\n"+
                "    'value.format' = 'debezium-json'" +
                //"    'scan.startup.mode' = 'latest-offset' " +
                ")");

        tableEnvironment.executeSql("Create table IF NOT EXISTS hTable (\n" +
                        " rowkey STRING,\n" +
                        " familyDetailed ROW<sname string, gender string,grade string,`timestamp` string>,\n" +
                        " PRIMARY KEY (rowkey) NOT ENFORCED " +
                ") WITH (\n" +
                        " 'connector' = 'hbase-1.4',\n" +
                        " 'table-name' = 'mytable',\n" +
                        " 'zookeeper.quorum' = 'hadoop162:2181,hadoop163:2181,hadoop164:2181' " +
                ")");

//        tableEnvironment.executeSql("CREATE TABLE KafkaTable (\n" +
//                        " `date` TIMESTAMP(3) METADATA FROM 'value.source.timestamp' VIRTUAL,\n" +  // from Debezium format
//                " `origin_table` STRING METADATA FROM 'value.source.table' VIRTUAL,\n" + // from Debezium format
//                " `partition_id` BIGINT METADATA FROM 'partition' VIRTUAL,\n" +  // from Kafka connector
//                " `offset` BIGINT METADATA VIRTUAL,\n" +  // from Kafka connector
//                " `id` BIGINT,\n" +
//                        " `name` string,\n" +
//                        " `addr` STRING" +
//                        ") WITH (\n" +
//                        " 'connector' = 'kafka',\n" +
//                        " 'topic' = 'mqTest02',\n" +
//                        " 'properties.bootstrap.servers' = 'hadoop162:9092,hadoop163:9092,hadoop164:9092',\n" +
//                        " 'properties.group.id' = 'testGroup',\n" +
//                        " 'scan.startup.mode' = 'latest-offset',\n" +
//                        " 'value.format' = 'debezium-json'" +
//                        ")");

        tableEnvironment.executeSql("insert into sink select * from demoOrders");
       // tableEnvironment.executeSql("INSERT INTO hTable SELECT CAST(id as VARCHAR) as rowkey, ROW(sname,gender,grade,`timestamp`) FROM sink");

        //tableEnvironment.executeSql("INSERT INTO hTable SELECT CAST(id as VARCHAR) as rowkey, ROW(sname,gender,grade,`timestamp`) FROM sink").print();


    }
}
