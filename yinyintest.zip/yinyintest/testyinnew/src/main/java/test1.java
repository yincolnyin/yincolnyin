import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.table.api.EnvironmentSettings;
import org.apache.flink.table.api.TableSchema;
import org.apache.flink.table.api.bridge.java.StreamTableEnvironment;
import org.apache.flink.table.catalog.ObjectPath;
import org.apache.flink.table.catalog.exceptions.TableNotExistException;
import org.apache.flink.table.types.logical.LogicalType;
import org.apache.flink.table.types.logical.LogicalTypeFamily;

import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class test1 {

    private static String getHbaseFieldDef(TableSchema schema, boolean time2Iint) {
        int fieldCount=schema.getFieldCount();
        String fieldDef= IntStream.range(0,fieldCount).mapToObj(i->{
                    String fieldName=schema.getFieldName(i).get();
                    if("time".equalsIgnoreCase(fieldName)){
                        fieldName="`time`";
                    }
                    String fieldType="";
                    LogicalType type=schema.getFieldDataType(i).get().getLogicalType();
                    if(type.getTypeRoot().getFamilies().contains(LogicalTypeFamily.DATETIME)){
                        if(time2Iint){
                            fieldType="BIGINT";
                        }else {
                            if(type.getTypeRoot().getFamilies().contains(LogicalTypeFamily.TIMESTAMP)) {
                                fieldType = "TIMESTAMP(3)";
                            }else if(type.getTypeRoot().getFamilies().contains(LogicalTypeFamily.TIME)) {
                                fieldType = "TIME";
                            }else{
                                fieldType = "DATE";
                            }
                        }
                    }else if(type.getTypeRoot().getFamilies().contains(LogicalTypeFamily.CHARACTER_STRING)||
                            type.getTypeRoot().getFamilies().contains(LogicalTypeFamily.BINARY_STRING)){
                        fieldType="STRING";
                    }else{
                        fieldType=type.toString();
                    };
                    return String.format("%s %s",fieldName,fieldType);
                })
                .collect(Collectors.joining(",","INFO ROW<",">,\n"));
        return fieldDef;
    }

    public static void main(String[] args) throws TableNotExistException {
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        EnvironmentSettings settings = EnvironmentSettings.newInstance().inStreamingMode().useBlinkPlanner().build();
        StreamTableEnvironment tableEnvironment = StreamTableEnvironment.create(env, settings);

        String catalogName = "oracle-catalog";
        String defaultDatabase = "orcl";
        String username = "yjk";
        String password = "123456";
        // String
        // jdbcUrl=String.format("jdbc:mysql://localhost:3306/%s?useUnicode=true&characterEncoding=utf8&serverTimezone=UTC",defaultDatabase);
        String jdbcUrl = "jdbc:oracle:thin:@192.168.1.135:1521";

        OracleCatalog oracleCatalog = new OracleCatalog(catalogName, defaultDatabase, username, password, jdbcUrl);
        tableEnvironment.registerCatalog(catalogName, oracleCatalog);
        tableEnvironment.useCatalog(catalogName);

        System.out.println(oracleCatalog.getTable(new ObjectPath("YJK", "CHARTEST")).getSchema());
        // System.out.println(oracleCatalog.listTables(new
        // ObjectPath("YJK","STUDENT").getDatabaseName()));
        // System.out.println(oracleCatalog.getDatabase(new
        // ObjectPath("YJK","STUDENT").getDatabaseName()));
        // System.out.println(oracleCatalog.listDatabases());
        // oracleCatalog.tableExists(new ObjectPath("YJK",""));



    }

}
