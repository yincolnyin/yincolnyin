class StudentDemo {
    public Student getStudent() {
        //Student s = new Student();
        //Student ss = s;

        //Student s = new Student();
        //return s;
        return new Student();//返回该返回值类型Student类的对象
    }
}

