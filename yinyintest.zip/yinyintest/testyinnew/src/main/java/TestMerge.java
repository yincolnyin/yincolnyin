import java.util.HashMap;
import java.util.Map;

public class TestMerge {
    public static void main(String[] args) {
        Map<String, Integer> map1 = new HashMap<>();
        map1.put("a",1);
        map1.put("b",2);
        map1.put("c",3);
        System.out.println(map1);
        //key不存在等于是map1.put(key, value),后面的处理失效。
        map1.merge("d",4,(v1,v2)->v2+100);
        //System.out.println(map1);
        //如果存在就会变成你处理后的value值
        map1.merge("a",100,(v1,v2)->v1+v2);
        System.out.println(map1);
        map1.merge("c",3,Integer::sum);
        map1.merge("a",4,(v1,v2)->null);
        System.out.println(map1);
    }

}
