import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.table.api.EnvironmentSettings;
import org.apache.flink.table.api.TableSchema;
import org.apache.flink.table.api.bridge.java.StreamTableEnvironment;
import org.apache.flink.table.catalog.CatalogBaseTable;
import org.apache.flink.table.catalog.ObjectPath;
import org.apache.flink.table.catalog.exceptions.TableNotExistException;
import org.apache.flink.table.types.logical.LogicalType;
import org.apache.flink.table.types.logical.LogicalTypeFamily;

import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class JdbcCatalogTest {

    private static String getHbaseFieldDef(TableSchema schema, boolean time2Iint) {
        int fieldCount=schema.getFieldCount();
        String fieldDef= IntStream.range(1,fieldCount).mapToObj(i->{
                    String fieldName=schema.getFieldName(i).get();
                    if("time".equalsIgnoreCase(fieldName)){
                        fieldName="`time`";
                    }
                    String fieldType="";
                    LogicalType type=schema.getFieldDataType(i).get().getLogicalType();
                    if(type.getTypeRoot().getFamilies().contains(LogicalTypeFamily.DATETIME)){
                        if(time2Iint){
                            fieldType="BIGINT";
                        }else {
                            if(type.getTypeRoot().getFamilies().contains(LogicalTypeFamily.TIMESTAMP)) {
                                fieldType = "TIMESTAMP(3)";
                            }else if(type.getTypeRoot().getFamilies().contains(LogicalTypeFamily.TIME)) {
                                fieldType = "TIME";
                            }else{
                                fieldType = "DATE";
                            }
                        }
                    }else if(type.getTypeRoot().getFamilies().contains(LogicalTypeFamily.CHARACTER_STRING)||
                            type.getTypeRoot().getFamilies().contains(LogicalTypeFamily.BINARY_STRING)){
                        fieldType="STRING";
                    }else{
                        fieldType=type.toString();
                    };
                    return String.format("%s %s",fieldName,fieldType);
                })
                .collect(Collectors.joining(",","INFO ROW<",">,\n"));
        return fieldDef;
    }

    public static void main(String[] args) throws TableNotExistException {
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        EnvironmentSettings settings = EnvironmentSettings.newInstance().inStreamingMode().useBlinkPlanner().build();
        StreamTableEnvironment tableEnvironment = StreamTableEnvironment.create(env, settings);

        String catalogName = "mysql-catalog";
        String defaultDatabase = "default_database";
        String username = "root";
        String password = "123456";
        String jdbcUrl = "jdbc:mysql://localhost:3306/";

        MysqlCatalog mysqlCatalog = new MysqlCatalog(catalogName, defaultDatabase, username, password, jdbcUrl);
        tableEnvironment.registerCatalog(catalogName, mysqlCatalog);
        tableEnvironment.useCatalog(catalogName);
        //TableSchema schema = mysqlCatalog.getTable(new ObjectPath("information", "tables")).getSchema();
        //String fieldDef;
        System.out.println(mysqlCatalog.getTable(new ObjectPath("information", "tables")).getSchema());
//        boolean time2Iint = true;
//        fieldDef = getHbaseFieldDef(schema,time2Iint);
//        System.out.println(fieldDef);
    }
}
