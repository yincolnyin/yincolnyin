

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ConfigUtil {

    private String configDbUrl;
    private String configDbUserName;
    private String configDbPwd;
    private String decryptPwd;
    private String jobName;
    private String srcTable;
    private String Kafka_SQL="select key,value from dc_config.cdc_config where type='kafka'";
    private String Db_SQL="select key,value  from dc_config.cdc_config where type='db'";
    private String CDC_SQL1="select id,src_db,src_table,src_kafka,src_topic,src_topic_mode," +
            " src_topic_offset,src_ddl,target_db,target_table,target_ddl,exec_dml,job_name from dc_config.cdc_job_config " +
            " where state='1' and job_name=?";
    private String CDC_SQL2="select id,src_db,src_table,src_kafka,src_topic,src_topic_mode," +
            " src_topic_offset,src_ddl,target_db,target_table,target_ddl,exec_dml,job_name from dc_config.cdc_job_config " +
            " where state='1' and job_name=? and src_table=?";
    public static String KEY_url="url";
    public static String KEY_catalog_url="catalog_url";
    public static String KEY_driver="driver";
    public static String KEY_username="username";
    public static String KEY_pwd="pwd";
    public static String KEY_bootstrap="bootstrap";
    private Map<String,String> kafkaConfig=null;
    private Map<String,String> dbConfig=null;

    public List<Map<String, String>> getCdcConfigs() {
        return cdcConfigs;
    }


    private List<Map<String,String>> cdcConfigs =null;
    private Map<String,Map<String,String>> cdcConfigByName=new HashMap<String,Map<String,String>>();


    public  ConfigUtil(String url,String username,String pwd,String jobName,String srcTable) throws Exception {
        this.configDbUrl=url;
        this.configDbUserName=username;
        this.configDbPwd=pwd;
        this.decryptPwd=DESUtil.decrypt(configDbPwd);
        this.jobName=jobName;
        this.srcTable=srcTable;
        loadDbConfigs();
        loadKafkaConfigs();
        loadCdcConfigs();
    }
    private void loadKafkaConfigs() throws Exception {
        kafkaConfig=JdbcUtil.qryKv(configDbUrl,configDbUserName,decryptPwd,Kafka_SQL);
    }

    private void loadDbConfigs() throws Exception {
        dbConfig=JdbcUtil.qryKv(configDbUrl,configDbUserName,decryptPwd,Db_SQL);
    }

    private void loadCdcConfigs() throws Exception {
        if(this.srcTable==null||"".equals(this.srcTable)) {
            cdcConfigs = JdbcUtil.qryListWithParams(configDbUrl, configDbUserName, decryptPwd, CDC_SQL1, this.jobName);
        }else{
            cdcConfigs = JdbcUtil.qryListWithParams(configDbUrl, configDbUserName, decryptPwd, CDC_SQL2, this.jobName,this.srcTable);
        }
        for (Map<String, String> e : cdcConfigs) {
            this.cdcConfigByName.
                    put(String.join("", e.get("src_kafka"), e.get("src_topic")), e);
        }
    }

    public String getKafkaProperty(String kafkaName,String key){
        return this.kafkaConfig.get(String.join(".",kafkaName,key));
    }

    public String getDbProperty(String dbName,String key){
        return this.dbConfig.get(String.join(".",dbName,key));
    }
    public Map<String,String> getCdcConfig(String srcKafka,String srcTopic){
        return this.cdcConfigByName.get(String.join("",srcKafka,srcTopic));
    }
    public String getUrlOfDb(String dbName){
        String key=KEY_url;
        return this.getDbProperty(dbName,key);
    }
    public String getCatalogUrlOfDb(String dbName){
        String key=KEY_catalog_url;
        return this.getDbProperty(dbName,key);
    }
    public String getDriverOfDb(String dbName){
        String key=KEY_driver;
        return this.getDbProperty(dbName,key);
    }
    public String getUserNameOfDb(String dbName){
        String key=KEY_username;
        return this.getDbProperty(dbName,key);
    }
    public String getPwdOfDb(String dbName){
        String key=KEY_pwd;
        return DESUtil.decrypt(this.getDbProperty(dbName,key));
    }
    public String getBootstrapOfKafka(String kafkaName){
        String key=KEY_bootstrap;
        return this.getKafkaProperty(kafkaName,key);
    }

    public static void main(String[] args) throws Exception {
        String url= null;
        String username= null;
        String pwd = null;
        String jobName = null;
        String srcTable = null;
        ConfigUtil configUtil = new ConfigUtil(url,username,pwd,jobName,srcTable);
        configUtil.loadCdcConfigs();
    }


}
