import java.util.List;
import java.util.Map;

public class JdbcUtil {
    public static Map<String, String> qryKv(String configDbUrl, String configDbUserName, String decryptPwd, String kafka_sql) {
        return null;
    }

    public static List<Map<String, String>> qryListWithParams(String configDbUrl, String configDbUserName, String decryptPwd, String cdc_sql1, String ... params) {
        return null;
    }
}
