package Util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class JdbcUtil {

        public static void main(String[] args) {
            List<String> list = Arrays.asList("A","B","C","D");
            String result=  list.stream().collect(Collectors.joining(",","INFO ROW<",">,\n"));
            System.out.println(result);
            //INFO ROW<A,B,C,D>,
        }
}
