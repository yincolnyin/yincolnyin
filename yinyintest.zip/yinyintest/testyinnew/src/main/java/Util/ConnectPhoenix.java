package Util;

import org.apache.flink.api.common.state.ValueStateDescriptor;

import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class ConnectPhoenix {

    private Object conn;
    private Statement sm;

    public void prepare(){
        String url = "jdbc:phoenix:hadoop162,hadoop163,hadoop164:2181";

        //conn = JdbcUtil.getPhoenixConnection(url);

    }

    private void writeToPhoenix(){

        StringBuilder sql = new StringBuilder();
        sql
                .append("upsert into hTable values(id)");


    }


}
