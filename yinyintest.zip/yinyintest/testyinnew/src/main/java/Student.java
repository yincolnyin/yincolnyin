class Student {
    public void study() {
        System.out.println("Good Good Study,Day Day Up");
    }
}
