import com.alibaba.fastjson.JSONObject;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;


import java.io.*;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Json读取工具类
 */
public class JsonUtil {



    private static Object value;
    private static String key;
    private static Map<String, Object> sourceMap;
    private static Map<String, Object> sinkMap;
    private JSONObject jsonObject;

    private void getExtendKey() {

        JsonUtil jsonUtil = new JsonUtil();
        String jsonFile = jsonUtil.readJsonFile(new File("1.json"));
        if (jsonFile != null && !"".equals(jsonFile)) {
            jsonObject = JSONObject.parseObject(jsonFile);
            Map<String, Object> source = jsonObject.getJSONObject("source").getInnerMap();
            Map<String, Object> sink = jsonObject.getJSONObject("sink").getInnerMap();
            System.out.println(jsonObject.getJSONObject("source").getString("key1"));
            System.out.println(source);
            System.out.println(sink);
        }else {
            throw new RuntimeException("the value of column is null");
        }


//String sourceConfigKv = sourceExtendConfigMap.entrySet().stream().map(e -> String.format("'%s'='%s'", e.getKey(), e.getValue())).collect(Collectors.joining(","));


    }

    public static void main(String[] args) throws Exception {
        JsonUtil jsonUtil = new JsonUtil();
        jsonUtil.getExtendKey();


    }



    private static final Logger logger = LogManager.getLogger(JsonUtil.class);

    /**
     * 读取json文件
     * @return 返回json字符串
     */
    public String readJsonFile(File jsonFile) {
        String jsonStr = "";
        logger.info("begin" + jsonFile.getPath() + "file");
        try {
            //File jsonFile = new File(fileName);
            FileReader fileReader = new FileReader(jsonFile);
            Reader reader = new InputStreamReader(new FileInputStream(jsonFile), "utf-8");
            int ch = 0;
            StringBuffer sb = new StringBuffer();
            while ((ch = reader.read()) != -1) {
                sb.append((char) ch);
            }
            fileReader.close();
            reader.close();
            jsonStr = sb.toString();

            logger.info("read" + jsonFile.getPath() + "over!");
            return jsonStr;
        } catch (Exception e) {
            logger.info("————读取" + jsonFile.getPath() + "文件出现异常，读取失败!————");
            e.printStackTrace();
            return null;
        }
    }
}
