import java.util.HashMap;
import java.util.Map;

public class Config {
    public static void main(String[] args) {
        Map<String, Map<String,String>> cdcConfigByName=new HashMap<String,Map<String,String>>();
        Map<String, String>[] cdcConfigs = new Map[0];

    }
}
