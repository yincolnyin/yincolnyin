import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.table.api.EnvironmentSettings;
import org.apache.flink.table.api.bridge.java.StreamTableEnvironment;
import org.apache.flink.table.catalog.ObjectPath;
import org.apache.flink.table.catalog.exceptions.TableNotExistException;
import org.junit.Test;

public class JdbcCatalogTest {
    @Test
    public void test(String[] args) {
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        EnvironmentSettings settings = EnvironmentSettings.newInstance().inStreamingMode().useBlinkPlanner().build();
        StreamTableEnvironment tableEnvironment = StreamTableEnvironment.create(env, settings);

        String catalogName = "mysql-catalog";
        String defaultDatabase = "default_database";
        String username = "root";
        String password = "123456";
        String jdbcUrl = "jdbc:mysql://localhost:3306/day01?useUnicode=true&characterEncoding=utf8&serverTimezone=UTC";

        MysqlCatalog mysqlCatalog = new MysqlCatalog(catalogName, defaultDatabase, username, password, jdbcUrl);
        tableEnvironment.registerCatalog(catalogName,mysqlCatalog);
        tableEnvironment.useCatalog(catalogName);

        try {
            System.out.println(mysqlCatalog.getTable(ObjectPath.fromString("information.tables")));
        } catch (TableNotExistException e) {
            e.printStackTrace();
        }


    }
}
