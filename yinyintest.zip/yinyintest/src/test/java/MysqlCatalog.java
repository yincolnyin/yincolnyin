import org.apache.flink.table.api.DataTypes;
import org.apache.flink.table.api.TableSchema;
import org.apache.flink.table.catalog.*;
import org.apache.flink.table.catalog.exceptions.*;
import org.apache.flink.table.catalog.stats.CatalogColumnStatistics;
import org.apache.flink.table.catalog.stats.CatalogTableStatistics;
import org.apache.flink.table.expressions.Expression;
import org.apache.flink.table.types.DataType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MysqlCatalog extends AbstractCatalog {

    private Logger logger = LoggerFactory.getLogger(this.getClass());

    private static final String MYSQL_CLASS = "com.mysql.jdbc.Driver";

    public static final String MYSQL_TYPE_STRING = "string";
    public static final String MYSQL_TYPE_DOUBLE = "double";
    public static final String MYSQL_TYPE_TIMESTAMP = "timestamp";
    public static final String MYSQL_TYPE_BIGINT = "bigint";
    
    private Connection connection;

    public MysqlCatalog(String catalogName, String defaultDatabase, String username, String pwd, String connectUrl) {
        super(catalogName, defaultDatabase);
        try {
            Class.forName(MYSQL_CLASS);
            this.connection = DriverManager.getConnection(connectUrl,username,pwd);
        }catch (Exception e){
            throw new RuntimeException(e);
        }
    }
    @Override
    public void open() throws CatalogException {

    }

    @Override
    public void close() throws CatalogException {

    }

    @Override
    public List<String> listDatabases() throws CatalogException {
        return null;
    }

    @Override
    public CatalogDatabase getDatabase(String s) throws DatabaseNotExistException, CatalogException {
        return null;
    }

    @Override
    public boolean databaseExists(String s) throws CatalogException {
        return false;
    }

    @Override
    public void createDatabase(String s, CatalogDatabase catalogDatabase, boolean b) throws DatabaseAlreadyExistException, CatalogException {

    }

    @Override
    public void dropDatabase(String s, boolean b, boolean b1) throws DatabaseNotExistException, DatabaseNotEmptyException, CatalogException {

    }

    @Override
    public void alterDatabase(String s, CatalogDatabase catalogDatabase, boolean b) throws DatabaseNotExistException, CatalogException {

    }

    @Override
    public List<String> listTables(String s) throws DatabaseNotExistException, CatalogException {
        return null;
    }

    @Override
    public List<String> listViews(String s) throws DatabaseNotExistException, CatalogException {
        return null;
    }

    @Override
    public CatalogBaseTable getTable(ObjectPath tablePath) throws TableNotExistException, CatalogException {
        TableSchema.Builder builder = TableSchema.builder();

        String databaseName = tablePath.getDatabaseName();
        String tableName = tablePath.getObjectName();
        String pk = "";
        String watermarkRowTimeAttribute = "";
        String watermarkExpression = "";
        try {
            PreparedStatement ps = connection.prepareStatement("select tb.id, db.database_name, tb.tableName,tb.primaryKey, tb.watermarkRowTimeAttribute, tb.watermarkExpression, cl.columnName, cl.columnType, cl.expr FROM metadata_database db JOIN metadata_table tb ON db.id = tb.databaseId JOIN metadata_column cl ON tb.id = cl.tableId WHERE database_name =? AND tableName =?");
            ps.setString(1, databaseName);
            ps.setString(2, tableName);
            ResultSet rs = ps.executeQuery();

            while(rs.next()){
                if(rs.isFirst()){
                    //pk is primaryKey
                    pk = rs.getString("primaryKey");
                    watermarkRowTimeAttribute = rs.getString("watermarkRowTimeAttribute");
                    watermarkExpression = rs.getString("watermarkExpression");
                }
                String columnName = rs.getString("columnName");
                String columnType = rs.getString("columnType");
                String expr = rs.getString("expr");
                if(expr == null || "".equals(expr)){
                    builder.field(columnName,mappingType(columnType));
                }else{
                    builder.field(columnName,mappingType(columnType),expr);
                }
            }

        } catch (Exception e) {
            logger.error("get table fail",e);
        }

        //设置主键
        if(pk != null && !"".equals(pk)){
            builder.primaryKey(pk.split(";"));
        }
        //设置watermark
        if(watermarkExpression != null && !"".equals(watermarkExpression)){
            builder.watermark(watermarkRowTimeAttribute,watermarkExpression, DataTypes.TIMESTAMP(3));
        }

        TableSchema schema = builder.build();
        return new CatalogTableImpl(schema, getPropertiesFromMysql(databaseName,tableName), "").copy();

    }

    private Map<String, String> getPropertiesFromMysql(String databaseName, String tableName) {
        Map<String, String> map = new HashMap<>();

        String sql = "select tp.keyword,tp.valueword from metadata_database db join metadata_table tb on db.id=tb.databaseId join metadata_table_properties tp on tp.tableId=tb.id where database_name=? and tableName=?";
        try {
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1,databaseName);
            ps.setString(2,tableName);
            ResultSet rs = ps.executeQuery();
            while (rs.next()){
                map.put(rs.getString("key"),rs.getString("value"));
            }
        }catch (Exception e){
            logger.error("get table's properties fail",e);
        }

        return map;
    }

    private DataType mappingType(String mysqlType) {
        switch (mysqlType) {
            case MYSQL_TYPE_BIGINT:
                return DataTypes.BIGINT();
            case MYSQL_TYPE_DOUBLE:
                return DataTypes.DOUBLE();
            case MYSQL_TYPE_STRING:
                return DataTypes.STRING();
            case MYSQL_TYPE_TIMESTAMP:
                return DataTypes.TIMESTAMP(3);
            default:
                throw new UnsupportedOperationException("current not support " + mysqlType);
        }
    }

    @Override
    public boolean tableExists(ObjectPath objectPath) throws CatalogException {
        return false;
    }

    @Override
    public void dropTable(ObjectPath objectPath, boolean b) throws TableNotExistException, CatalogException {

    }

    @Override
    public void renameTable(ObjectPath objectPath, String s, boolean b) throws TableNotExistException, TableAlreadyExistException, CatalogException {

    }

    @Override
    public void createTable(ObjectPath objectPath, CatalogBaseTable catalogBaseTable, boolean b) throws TableAlreadyExistException, DatabaseNotExistException, CatalogException {

    }

    @Override
    public void alterTable(ObjectPath objectPath, CatalogBaseTable catalogBaseTable, boolean b) throws TableNotExistException, CatalogException {

    }

    @Override
    public List<CatalogPartitionSpec> listPartitions(ObjectPath objectPath) throws TableNotExistException, TableNotPartitionedException, CatalogException {
        return null;
    }

    @Override
    public List<CatalogPartitionSpec> listPartitions(ObjectPath objectPath, CatalogPartitionSpec catalogPartitionSpec) throws TableNotExistException, TableNotPartitionedException, PartitionSpecInvalidException, CatalogException {
        return null;
    }

    @Override
    public List<CatalogPartitionSpec> listPartitionsByFilter(ObjectPath objectPath, List<Expression> list) throws TableNotExistException, TableNotPartitionedException, CatalogException {
        return null;
    }

    @Override
    public CatalogPartition getPartition(ObjectPath objectPath, CatalogPartitionSpec catalogPartitionSpec) throws PartitionNotExistException, CatalogException {
        return null;
    }

    @Override
    public boolean partitionExists(ObjectPath objectPath, CatalogPartitionSpec catalogPartitionSpec) throws CatalogException {
        return false;
    }

    @Override
    public void createPartition(ObjectPath objectPath, CatalogPartitionSpec catalogPartitionSpec, CatalogPartition catalogPartition, boolean b) throws TableNotExistException, TableNotPartitionedException, PartitionSpecInvalidException, PartitionAlreadyExistsException, CatalogException {

    }

    @Override
    public void dropPartition(ObjectPath objectPath, CatalogPartitionSpec catalogPartitionSpec, boolean b) throws PartitionNotExistException, CatalogException {

    }

    @Override
    public void alterPartition(ObjectPath objectPath, CatalogPartitionSpec catalogPartitionSpec, CatalogPartition catalogPartition, boolean b) throws PartitionNotExistException, CatalogException {

    }

    @Override
    public List<String> listFunctions(String s) throws DatabaseNotExistException, CatalogException {
        return null;
    }

    @Override
    public CatalogFunction getFunction(ObjectPath objectPath) throws FunctionNotExistException, CatalogException {
        return null;
    }

    @Override
    public boolean functionExists(ObjectPath objectPath) throws CatalogException {
        return false;
    }

    @Override
    public void createFunction(ObjectPath objectPath, CatalogFunction catalogFunction, boolean b) throws FunctionAlreadyExistException, DatabaseNotExistException, CatalogException {

    }

    @Override
    public void alterFunction(ObjectPath objectPath, CatalogFunction catalogFunction, boolean b) throws FunctionNotExistException, CatalogException {

    }

    @Override
    public void dropFunction(ObjectPath objectPath, boolean b) throws FunctionNotExistException, CatalogException {

    }

    @Override
    public CatalogTableStatistics getTableStatistics(ObjectPath objectPath) throws TableNotExistException, CatalogException {
        return null;
    }

    @Override
    public CatalogColumnStatistics getTableColumnStatistics(ObjectPath objectPath) throws TableNotExistException, CatalogException {
        return null;
    }

    @Override
    public CatalogTableStatistics getPartitionStatistics(ObjectPath objectPath, CatalogPartitionSpec catalogPartitionSpec) throws PartitionNotExistException, CatalogException {
        return null;
    }

    @Override
    public CatalogColumnStatistics getPartitionColumnStatistics(ObjectPath objectPath, CatalogPartitionSpec catalogPartitionSpec) throws PartitionNotExistException, CatalogException {
        return null;
    }

    @Override
    public void alterTableStatistics(ObjectPath objectPath, CatalogTableStatistics catalogTableStatistics, boolean b) throws TableNotExistException, CatalogException {

    }

    @Override
    public void alterTableColumnStatistics(ObjectPath objectPath, CatalogColumnStatistics catalogColumnStatistics, boolean b) throws TableNotExistException, CatalogException, TablePartitionedException {

    }

    @Override
    public void alterPartitionStatistics(ObjectPath objectPath, CatalogPartitionSpec catalogPartitionSpec, CatalogTableStatistics catalogTableStatistics, boolean b) throws PartitionNotExistException, CatalogException {

    }

    @Override
    public void alterPartitionColumnStatistics(ObjectPath objectPath, CatalogPartitionSpec catalogPartitionSpec, CatalogColumnStatistics catalogColumnStatistics, boolean b) throws PartitionNotExistException, CatalogException {

    }
}
