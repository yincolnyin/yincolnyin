//package yinyintest;
//
//import org.apache.catalina.User;
//import org.apache.flink.configuration.Configuration;
//import org.apache.flink.streaming.api.functions.sink.RichSinkFunction;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//
//import java.sql.Connection;
//import java.sql.DriverManager;
//import java.sql.PreparedStatement;
//import java.sql.SQLException;
//
//public class MysqlSink extends RichSinkFunction<User> {
//
//    private Connection connection = null;
//
//    private PreparedStatement ps = null;
//    @Override
//    public void invoke(User value, Context context)  {
//        System.out.println("MysqlSink -- open --33-");
//        try {
//            ps.setString(1, value.getUserId());
//            ps.setString(2, value.getUserName());
//            ps.setString(3, value.getUserNameCn());
//            ps.setString(4, value.getTel());
//
//            ps.executeUpdate();
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }
//
//        System.out.println("MysqlSink -- invoke ---"+value.toString());
//    }
//
//    @Override
//    public void open(Configuration parameters){
//        System.out.println("MysqlSink -- open --11-");
//        try {
//            super.open(parameters);
//            Class.forName("com.mysql.cj.jdbc.Driver");//加载数据库驱动
//
//            connection = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/tableName?serverTimezone=UTC&useUnicode=true&characterEncoding=utf8&useSSL=false", "userNmae", "pwd");//获取连接
//            ps = connection.prepareStatement("insert into SYS_USER (USER_ID,USER_NAME,USER_NAME_CN,TEL) values(?,?,?,?)");
//        } catch (Exception e) {
//            e.printStackTrace();
//            System.out.println("MysqlSink -- open --Exception-" + e.toString());
//        }
//
//
//
//
//
//
//        System.out.println("MysqlSink -- open --22-");
//    }
//
//    @Override
//    public void close(){
//        try {
//
//            super.close();
//
//            if (connection != null) {
//
//                connection.close();
//
//            }
//
//            if (ps != null) {
//
//                ps.close();
//
//            }
//
//        } catch (Exception e) {
//
//            logger.error("runException:{}", e);
//
//        }
//    }
//}
