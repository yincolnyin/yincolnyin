//package yinyintest;
//
//import org.apache.catalina.User;
//import org.apache.flink.streaming.api.datastream.DataStreamSource;
//import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
//
//public class DbJob {
//    public static void main(String[] args) throws Exception {
//        StreamExecutionEnvironment fsEnv = StreamExecutionEnvironment.getExecutionEnvironment();
//        DataStreamSource<User> source = fsEnv.addSource(new OracleSource());
//        source.addSink(new MysqlSink());
//
//        fsEnv.execute();
//    }
//}

