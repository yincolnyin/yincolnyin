//package yinyintest;
//
//import org.apache.catalina.User;
//import org.apache.flink.configuration.Configuration;
//import org.apache.flink.streaming.api.functions.source.RichSourceFunction;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//
//import java.sql.*;
//
//public class OracleSource extends RichSourceFunction<User> {
//
//    private Connection connection = null;
//
//    private PreparedStatement ps = null;
//    @Override
//    public void open(Configuration parameters){
//
//        System.out.println("OracleSource -- open --11-");
//        try{
//            super.open(parameters);
//            Class.forName("oracle.jdbc.OracleDriver");
//
//            connection = DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:orcl", "username", "pwd");//获取连接
//            ps = connection.prepareStatement("select * from SYS_USER");
//        }catch (Exception e){
//            System.out.println("OracleSource -- open --Exception-" + e.toString());
//        }
//
//
//        System.out.println("OracleSource -- open --22-");
//    }
//
//    @Override
//    public void run(SourceContext<User> sourceContext){
//        System.out.println("OracleSource -- run --33-");
//        ResultSet res = null;
//        try {
//            res = ps.executeQuery();
//            while(res.next()){
//                User user = new User();
//                user.setUserId(res.getNString("USER_ID"));
//                user.setUserName(res.getNString("USER_NAME"));
//                user.setUserNameCn(res.getNString("USER_NAME_CN"));
//                user.setTel(res.getNString("TEL"));
//                sourceContext.collect(user);
//                System.out.println("OracleSource -- run ---"+user.toString());
//            }
//        } catch (SQLException e) {
//            e.printStackTrace();
//            System.out.println("OracleSource -- run --Exception-" + e.toString());
//        }
//
//        System.out.println("OracleSource -- run --22-");
//    }
//
//    @Override
//    public void cancel() {
//        try {
//
//            super.close();
//
//            if (connection != null) {
//
//                connection.close();
//
//            }
//
//            if (ps != null) {
//
//                ps.close();
//
//            }
//
//        } catch (Exception e) {
//
//            logger.error("runException:{}", e);
//
//        }
//    }
//}
