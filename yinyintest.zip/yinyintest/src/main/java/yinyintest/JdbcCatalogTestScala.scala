package yinyintest

import org.apache.flink.streaming.api.scala.StreamExecutionEnvironment
import org.apache.flink.table.api.EnvironmentSettings
import org.apache.flink.table.api.bridge.scala.StreamTableEnvironment


object JdbcCatalogTestScala {

  def void: Unit = {

    val env : StreamExecutionEnvironment = StreamExecutionEnvironment.getExecutionEnvironment
    val settings : EnvironmentSettings = EnvironmentSettings.newInstance().inStreamingMode().useBlinkPlanner().build()
    val tableEnv : StreamTableEnvironment = StreamTableEnvironment.create(env,settings)


    val catalogName = "mysql-catalog"
    val defaultDatabase = "default_database"
    val username = "root"
    val password = "123456"
    val jdbcUrl = "jdbc:mysql://localhost:3306/day01?useUnicode=true&characterEncoding=utf8&serverTimezone=UTC"


    //使用jdbc catalog
    val catalog : MysqlCatalog = new  MysqlCatalog(catalogName,defaultDatabase,username,password,jdbcUrl)
    tableEnv.registerCatalog(catalogName,catalog)
    tableEnv.useCatalog(catalogName)


    val queryDDL : String =
      """
        |insert into destinationTable
        |select * from sourceTable where deviceName <> '' and `region` <> ''
      """.stripMargin

    tableEnv.executeSql(queryDDL)

  }

}

